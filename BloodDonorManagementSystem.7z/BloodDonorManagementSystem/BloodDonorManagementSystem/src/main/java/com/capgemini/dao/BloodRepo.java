package com.capgemini.dao;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.beans.User;

public interface BloodRepo extends CrudRepository<User, String> {

}
