package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.User;

public interface BloodService {
	public User createUser(User user);
	public User findById(String id);
	public List<User> findUser();
	public List<User> findByBloodGroup(String bloodGroup);
	
}
