package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.User;
import com.capgemini.dao.BloodRepo;

@Service
public class BloodServiceImpl implements BloodService {
	
	@Autowired
	BloodRepo bloodRepo;
	

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		
		return bloodRepo.save(user) ;

	}

	@Override
	public List<User> findUser() {
		// TODO Auto-generated method stub
		List<User> u= (List<User>) bloodRepo.findAll();
		return u;
	}

	@Override
	public User findById(String id) {
		// TODO Auto-generated method stub
		Optional<User> user= bloodRepo.findById(id);
		
		return null;
	}

	@Override
	public List<User> findByBloodGroup(String bloodGroup) {
		// TODO Auto-generated method stub
		List<User> u= (List<User>) bloodRepo.findAll();
		System.out.println(bloodGroup);
		List<User> u1= new ArrayList<>();
		for (int i = 0; i < u.size(); i++) {
		    if(u.get(i).getBloodGroup().equals(bloodGroup)) {
		    	u1.add(u.get(i));
		    }
		}
		return u1;
	}

}
