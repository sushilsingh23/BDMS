package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.User;
import com.capgemini.service.BloodServiceImpl;

@RestController
public class MyController {
	
	@Autowired
	private BloodServiceImpl bloodServiceImpl;
	
	@RequestMapping(value = "/")
	String index() {
		return "Blood Donor Management System is ready.!";

	}
	
	@RequestMapping(path="/createUser", method=RequestMethod.POST)
	public User createUser(@RequestBody User user) {
		return bloodServiceImpl.createUser(user);
	}
	
	@RequestMapping(path="/findByBloodGroup/{bloodGroup}", method=RequestMethod.POST)
	public List<User> createUser(@PathVariable String bloodGroup) {
		return bloodServiceImpl.findByBloodGroup(bloodGroup);
	}
	
/*	@RequestMapping(path="/login", method=RequestMethod.POST)
	public List<User> login(@RequestBody User user) {
		return bloodServiceImpl.findByBloodGroup(bloodGroup);
	}*/
	
	
	@RequestMapping(value="/getAll", method=RequestMethod.GET)
	public List<User> getAll() 
	{
		 return bloodServiceImpl.findUser();
	}

}
