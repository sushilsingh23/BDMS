package com.bd.lifesavers.service;


import org.springframework.stereotype.Service;



@Service
public interface IEligibilityService {

	void setEligibility(Long eligible);

}
