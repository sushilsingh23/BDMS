package com.bd.lifesavers.domain;

public enum BloodGroup {
	O_positive, O_negative, A_positive, A_negative, B_positive, B_negative, AB_positive, AB_negative;
}
